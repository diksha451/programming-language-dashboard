"""
Programming Languages Analytics Dashboard — entry point.

Handles: page config, CSS injection, data loading (with error
handling), global filters, sidebar footer, and page navigation.
Individual pages read the prepared data from st.session_state.
"""

from pathlib import Path

import streamlit as st

from utils.cleaning import clean_data
from utils.data_loader import DataValidationError, load_dataset
from utils.filters import apply_filters, render_global_filters, render_sidebar_footer

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "programming_languages.csv"
CSS_PATH = BASE_DIR / "assets" / "styles.css"

st.set_page_config(
    page_title="Programming Languages Analytics",
    page_icon=None,
    layout="wide",
)


def inject_css() -> None:
    if CSS_PATH.exists():
        st.markdown(f"<style>{CSS_PATH.read_text()}</style>", unsafe_allow_html=True)


@st.cache_data(show_spinner="Loading dataset...")
def get_raw_data():
    return load_dataset(DATA_PATH)


def main() -> None:
    inject_css()

    st.sidebar.markdown("### Programming Languages Analytics")

    try:
        raw_df, warnings = get_raw_data()
    except FileNotFoundError as exc:
        st.error(str(exc))
        st.stop()
    except DataValidationError as exc:
        st.error(f"Data validation error: {exc}")
        st.stop()
    except Exception as exc:  # noqa: BLE001 — last-resort UI guard
        st.error(f"Unexpected error while loading data: {exc}")
        st.stop()

    for w in warnings:
        st.warning(w)

    # Global filters (rendered in sidebar, shared across all pages via widget keys)
    filters = render_global_filters(raw_df)
    filtered_df = apply_filters(raw_df, filters)
    cleaned_df = clean_data(raw_df)

    # Make everything available to individual pages
    st.session_state["raw_df"] = raw_df
    st.session_state["filtered_df"] = filtered_df
    st.session_state["cleaned_df"] = cleaned_df

    render_sidebar_footer(raw_df)

    pages = [
        st.Page("pages/dashboard.py", title="Dashboard", default=True),
        st.Page("pages/data_explorer.py", title="Data Explorer"),
        st.Page("pages/analytics.py", title="Analytics"),
        st.Page("pages/data_quality.py", title="Data Quality"),
        st.Page("pages/insights.py", title="Insights"),
        st.Page("pages/export.py", title="Export"),
    ]
    pg = st.navigation(pages)
    pg.run()


if __name__ == "__main__":
    main()
