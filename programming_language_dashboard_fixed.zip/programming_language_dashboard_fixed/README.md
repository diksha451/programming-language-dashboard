# Programming Languages Analytics Dashboard

A multi-page Streamlit analytics application for exploring programming
languages by popularity, difficulty, paradigm, typing system, release year,
and use cases — built from a single CSV file, no database involved.

## 1. Architecture

```
CSV file
   ↓
utils/data_loader.py   → reads + validates schema, coerces numeric types
   ↓
app.py (@st.cache_data) → caches the loaded dataset
   ↓
utils/filters.py        → global sidebar filters, applied to the raw data
   ↓
utils/analytics.py      → rankings, grouping, use-case parsing, insights
utils/cleaning.py       → data-quality report + in-memory cleaned copy
utils/charts.py         → Plotly figure builders (shared theme)
   ↓
pages/*.py               → six pages, each rendering one section of the app
   ↓
Streamlit web app
```

No SQL, no ORM, no external database — pandas in memory is the only data
layer, exactly as required.

## 2. Folder structure

```
programming_language_dashboard/
├── app.py                      # Entry point: config, data load, filters, navigation
├── requirements.txt
├── README.md
│
├── data/
│   └── programming_languages.csv
│
├── pages/                      # One file per section (Streamlit's native
│   ├── dashboard.py             # multi-page routing, driven by st.navigation
│   ├── data_explorer.py         # in app.py — see note below)
│   ├── analytics.py
│   ├── data_quality.py
│   ├── insights.py
│   └── export.py
│
├── utils/
│   ├── data_loader.py           # CSV loading + schema validation
│   ├── cleaning.py              # Data-quality report + cleaning
│   ├── analytics.py             # Rankings, grouping, insights, use-case parsing
│   └── filters.py               # Global filters shared across all pages
│
└── assets/
    └── styles.css                # Custom CSS for the professional look
```

**Note on navigation:** the app uses Streamlit's modern `st.navigation` /
`st.Page` API (set up in `app.py`) instead of Streamlit's older automatic
"drop files in `pages/` and get default navigation" behavior. This gives
full control over the sidebar labels ("Dashboard", "Data Explorer", etc.)
and lets `app.py` load the data and filters once, then hand off to whichever
page is selected — avoiding duplicated data-loading code in every page file.

## 3. UI design plan

- **Sidebar:** app title, global filters (Language, Difficulty, Popularity,
  Year Created, Paradigm, Typing, Use Case — all built dynamically from the
  dataset, never hardcoded), page navigation, and a footer showing
  "Programming Languages / N Languages Loaded" computed live from the CSV.
- **Cards:** KPI values and insights are rendered as custom-styled cards
  (`assets/styles.css`) instead of default Streamlit metrics, with a subtle
  hover effect for a more polished feel.
- **Charts:** all Plotly charts share one color palette and a clean white
  template so the app reads as one cohesive product.
- **Empty/error states:** every page checks for empty filtered data and
  shows a centered, styled message instead of crashing or showing a blank
  page.
- **No emojis in navigation** — page titles are plain text, per spec.

## 4. Data flow

1. `app.py` loads `data/programming_languages.csv` via
   `utils/data_loader.py`, which validates that all required columns exist
   and coerces numeric columns, dropping/reporting anything unusable.
2. The result is cached with `@st.cache_data` so it's only read from disk
   once per session.
3. `utils/filters.py` renders the global filter widgets and returns the
   filtered dataframe.
4. `utils/cleaning.py` produces a separate in-memory cleaned dataframe —
   the original CSV and the raw in-memory dataframe are never modified.
5. All three dataframes (raw, filtered, cleaned) are stored in
   `st.session_state` so every page can access them without reloading.
6. Each page in `pages/` pulls what it needs from `st.session_state` and
   renders its section using `utils/analytics.py` and `utils/charts.py`.

## 5. Setup

```bash
# 1. Open the project folder
cd programming_language_dashboard

# 2. Create a virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # macOS/Linux

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
streamlit run app.py
# if 'streamlit' is not recognized as a command, use:
python -m streamlit run app.py
```

The app opens at `http://localhost:8501`.

## 6. Running in VS Code

1. Open the `programming_language_dashboard` folder in VS Code
   (`File → Open Folder`).
2. Open a terminal inside VS Code: `` Ctrl + ` `` (backtick).
3. Create and activate the virtual environment (commands above).
4. In VS Code, press `Ctrl+Shift+P` → "Python: Select Interpreter" → choose
   the `venv` interpreter so IntelliSense and linting use the right
   environment.
5. In the same terminal, run:
   ```bash
   streamlit run app.py
   ```
6. VS Code will show the local URL in the terminal — `Ctrl+Click` it to
   open the app in your browser. Every time you save a file, Streamlit
   will offer to "Rerun" in the browser tab.

## 7. Using your own dataset

Replace `data/programming_languages.csv`, keeping these columns:

| column         | type   | notes                              |
|----------------|--------|-------------------------------------|
| `language`     | text   | unique per row                      |
| `difficulty`   | number | expected range 1–5                  |
| `popularity`   | number | any positive scale                  |
| `use_cases`    | text   | semicolon-separated, e.g. `AI; Web` |
| `year_created` | number | 4-digit year                        |
| `paradigm`     | text   | e.g. Object-oriented                |
| `typing`       | text   | e.g. Static / Dynamic               |

If the file is missing, empty, or missing a required column, the app shows
a clear error message instead of crashing. Out-of-range or invalid values
are reported as warnings and handled in the Data Quality page rather than
breaking the app.

## 8. Tech stack

- **Streamlit** — multi-page app framework, native navigation, caching
- **pandas** — data loading, validation, cleaning, aggregation
- **Plotly** — interactive, consistently themed charts

## License

MIT
