"""
Global filters, rendered identically on every page.

Because every widget below uses a fixed, unique `key`, Streamlit
persists each widget's value in st.session_state automatically —
so a filter set on the Dashboard page stays applied when the user
switches to Data Explorer, Analytics, etc.
"""

from dataclasses import dataclass
from typing import Tuple

import pandas as pd
import streamlit as st

from utils.analytics import split_use_cases


@dataclass(frozen=True)
class Filters:
    languages: tuple
    difficulty_range: tuple
    popularity_range: tuple
    year_range: tuple
    paradigms: tuple
    typings: tuple
    use_cases: tuple


def _options_or_all(selected, all_options):
    return tuple(selected) if selected else tuple(all_options)


def render_global_filters(df: pd.DataFrame) -> Filters:
    st.sidebar.markdown("#### Filters")

    all_languages = sorted(df["language"].unique())
    languages = st.sidebar.multiselect("Language", all_languages, key="flt_language")

    diff_min, diff_max = int(df["difficulty"].min()), int(df["difficulty"].max())
    difficulty_range = st.sidebar.slider(
        "Difficulty", diff_min, diff_max, (diff_min, diff_max), key="flt_difficulty"
    )

    pop_min, pop_max = float(df["popularity"].min()), float(df["popularity"].max())
    popularity_range = st.sidebar.slider(
        "Popularity", pop_min, pop_max, (pop_min, pop_max), key="flt_popularity"
    )

    year_min, year_max = int(df["year_created"].min()), int(df["year_created"].max())
    year_range = st.sidebar.slider(
        "Year created", year_min, year_max, (year_min, year_max), key="flt_year"
    )

    all_paradigms = sorted(df["paradigm"].unique())
    paradigms = st.sidebar.multiselect("Paradigm", all_paradigms, key="flt_paradigm")

    all_typings = sorted(df["typing"].unique())
    typings = st.sidebar.multiselect("Typing", all_typings, key="flt_typing")

    all_use_cases = sorted(split_use_cases(df)["use_case"].unique())
    use_cases = st.sidebar.multiselect("Use case", all_use_cases, key="flt_use_case")

    st.sidebar.divider()

    return Filters(
        languages=_options_or_all(languages, all_languages),
        difficulty_range=difficulty_range,
        popularity_range=popularity_range,
        year_range=year_range,
        paradigms=_options_or_all(paradigms, all_paradigms),
        typings=_options_or_all(typings, all_typings),
        use_cases=_options_or_all(use_cases, all_use_cases),
    )


def apply_filters(df: pd.DataFrame, filters: Filters) -> pd.DataFrame:
    mask = (
        df["language"].isin(filters.languages)
        & df["difficulty"].between(*filters.difficulty_range)
        & df["popularity"].between(*filters.popularity_range)
        & df["year_created"].between(*filters.year_range)
        & df["paradigm"].isin(filters.paradigms)
        & df["typing"].isin(filters.typings)
    )
    result = df[mask]

    # use-case filter: keep rows where ANY selected use case appears in that row's list
    if filters.use_cases:
        all_use_case_options = filters.use_cases
        result = result[
            result["use_cases"].apply(
                lambda cell: any(
                    uc.strip() in all_use_case_options for uc in str(cell).split(";")
                )
            )
        ]

    return result.reset_index(drop=True)


def render_sidebar_footer(raw_df: pd.DataFrame) -> None:
    st.sidebar.markdown(
        f"""
        <div class="sidebar-footer">
            <div class="sidebar-footer-title">Programming Languages</div>
            <div class="sidebar-footer-count">{len(raw_df)} Languages Loaded</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
