"""
Data loading layer.

Loads the CSV and validates the schema. No Streamlit imports here —
caching is applied by the caller (app.py) so this module stays
independently testable.
"""

from pathlib import Path
from typing import List, Tuple

import pandas as pd

REQUIRED_COLUMNS = [
    "language", "difficulty", "popularity", "use_cases",
    "year_created", "paradigm", "typing",
]

NUMERIC_COLUMNS = ["difficulty", "popularity", "year_created"]


class DataValidationError(Exception):
    """Raised when the CSV is missing required columns or is unusable."""


def load_raw_csv(path: Path) -> pd.DataFrame:
    """Read the CSV file from disk. Raises FileNotFoundError / DataValidationError."""
    if not path.exists():
        raise FileNotFoundError(
            "Dataset not found. Please place programming_languages.csv inside the data folder."
        )

    try:
        df = pd.read_csv(path)
    except pd.errors.EmptyDataError as exc:
        raise DataValidationError("The dataset file is empty.") from exc
    except pd.errors.ParserError as exc:
        raise DataValidationError(f"The dataset file could not be parsed: {exc}") from exc

    if df.empty:
        raise DataValidationError("The dataset contains no rows.")

    return df


def validate_schema(df: pd.DataFrame) -> None:
    """Raise DataValidationError if required columns are missing."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise DataValidationError(
            f"Required column(s) missing from dataset: {', '.join(missing)}"
        )


def coerce_numeric(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    """
    Coerce numeric columns and report rows that became unusable.
    Returns the (possibly trimmed) dataframe and a list of warning strings.
    """
    df = df.copy()
    warnings: List[str] = []

    for col in NUMERIC_COLUMNS:
        before_na = df[col].isna().sum()
        df[col] = pd.to_numeric(df[col], errors="coerce")
        after_na = df[col].isna().sum()
        newly_invalid = after_na - before_na
        if newly_invalid > 0:
            warnings.append(f"{newly_invalid} value(s) in '{col}' were invalid and treated as missing.")

    before_rows = len(df)
    df = df.dropna(subset=["language", *NUMERIC_COLUMNS])
    dropped = before_rows - len(df)
    if dropped:
        warnings.append(f"{dropped} row(s) dropped due to missing required values.")

    return df.reset_index(drop=True), warnings


def load_dataset(path: Path) -> Tuple[pd.DataFrame, List[str]]:
    """Full load pipeline: read, validate schema, coerce numerics."""
    df = load_raw_csv(path)
    validate_schema(df)
    df, warnings = coerce_numeric(df)
    if df.empty:
        raise DataValidationError("No valid rows remained after cleaning invalid values.")
    return df, warnings
