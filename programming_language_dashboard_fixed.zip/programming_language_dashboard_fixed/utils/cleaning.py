"""
Data quality + cleaning layer.

data_quality_report() inspects the raw dataframe without modifying it.
clean_data() returns a NEW cleaned dataframe — the original is never
touched or overwritten.
"""

from datetime import date
from typing import Dict, List

import pandas as pd

DIFFICULTY_MIN, DIFFICULTY_MAX = 1, 5
YEAR_MIN, YEAR_MAX = 1950, date.today().year


def data_quality_report(df: pd.DataFrame) -> Dict:
    """Compute a structured data-quality report from the raw dataframe."""
    return {
        "total_rows": len(df),
        "total_columns": df.shape[1],
        "missing_values": df.isna().sum().to_dict(),
        "duplicate_rows": int(df.duplicated().sum()),
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
        "unique_values": {col: int(df[col].nunique()) for col in df.columns},
        "numeric_summary": df.select_dtypes(include="number").describe(),
    }


def validate_values(df: pd.DataFrame) -> List[str]:
    """Return a list of human-readable data validation issues found in df."""
    issues: List[str] = []

    if "difficulty" in df.columns:
        bad = ~df["difficulty"].between(DIFFICULTY_MIN, DIFFICULTY_MAX)
        if bad.any():
            issues.append(
                f"{int(bad.sum())} row(s) have 'difficulty' outside the expected "
                f"{DIFFICULTY_MIN}-{DIFFICULTY_MAX} range."
            )

    if "year_created" in df.columns:
        bad_year = ~df["year_created"].between(YEAR_MIN, YEAR_MAX)
        if bad_year.any():
            issues.append(
                f"{int(bad_year.sum())} row(s) have 'year_created' outside the "
                f"plausible {YEAR_MIN}-{YEAR_MAX} range."
            )

    if "popularity" in df.columns:
        bad_pop = df["popularity"] < 0
        if bad_pop.any():
            issues.append(f"{int(bad_pop.sum())} row(s) have a negative 'popularity' value.")

    if "language" in df.columns:
        empty_lang = df["language"].astype(str).str.strip().eq("").sum()
        if empty_lang:
            issues.append(f"{int(empty_lang)} row(s) have an empty 'language' value.")

        dupes = df["language"].duplicated().sum()
        if dupes:
            issues.append(f"{int(dupes)} duplicate 'language' entries found.")

    dup_rows = df.duplicated().sum()
    if dup_rows:
        issues.append(f"{int(dup_rows)} fully duplicate row(s) found.")

    return issues


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Return a cleaned COPY of df:
    - strips whitespace on text columns
    - drops fully duplicate rows
    - drops rows with empty language
    - drops rows with difficulty/year outside plausible ranges
    - drops rows with negative popularity
    The original dataframe passed in is never modified.
    """
    cleaned = df.copy()

    text_cols = cleaned.select_dtypes(include="object").columns
    for col in text_cols:
        cleaned[col] = cleaned[col].astype(str).str.strip()

    cleaned = cleaned.drop_duplicates()
    cleaned = cleaned[cleaned["language"].str.len() > 0]

    if "difficulty" in cleaned.columns:
        cleaned = cleaned[cleaned["difficulty"].between(DIFFICULTY_MIN, DIFFICULTY_MAX)]

    if "year_created" in cleaned.columns:
        cleaned = cleaned[cleaned["year_created"].between(YEAR_MIN, YEAR_MAX)]

    if "popularity" in cleaned.columns:
        cleaned = cleaned[cleaned["popularity"] >= 0]

    cleaned = cleaned.drop_duplicates(subset=["language"])

    return cleaned.reset_index(drop=True)
