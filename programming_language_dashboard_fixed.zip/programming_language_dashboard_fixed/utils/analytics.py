"""
Analytics layer — every function computes results directly from the
dataframe passed in. Nothing here is hardcoded; all insights reflect
whatever data the caller supplies (raw or filtered).
"""

from typing import Dict, Optional

import pandas as pd


def split_use_cases(df: pd.DataFrame) -> pd.DataFrame:
    """
    Explode the semicolon-separated 'use_cases' column into one row
    per (language, use_case) pair. Whitespace is trimmed and empty
    values are dropped. The original 'use_cases' column is untouched
    in the source dataframe — this returns a new exploded frame for
    analysis only.
    """
    working = df.copy()
    working["use_case"] = working["use_cases"].astype(str).str.split(";")
    working = working.explode("use_case")
    working["use_case"] = working["use_case"].str.strip()
    working = working[working["use_case"].str.len() > 0]
    return working.reset_index(drop=True)


def use_case_counts(df: pd.DataFrame) -> pd.DataFrame:
    exploded = split_use_cases(df)
    counts = exploded["use_case"].value_counts().reset_index()
    counts.columns = ["use_case", "count"]
    return counts


def avg_popularity_by_use_case(df: pd.DataFrame) -> pd.DataFrame:
    exploded = split_use_cases(df)
    result = (
        exploded.groupby("use_case")["popularity"]
        .mean()
        .round(1)
        .reset_index()
        .sort_values("popularity", ascending=False)
    )
    return result


def add_decade(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["decade"] = (df["year_created"] // 10 * 10).astype(int).astype(str) + "s"
    return df


def top_n(df: pd.DataFrame, col: str, n: int = 5, ascending: bool = False) -> pd.DataFrame:
    return df.sort_values(col, ascending=ascending).head(n).reset_index(drop=True)


def group_stats(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
    return (
        df.groupby(group_col)[["popularity", "difficulty"]]
        .mean()
        .round(2)
        .reset_index()
        .sort_values("popularity", ascending=False)
    )


def decade_counts(df: pd.DataFrame) -> pd.DataFrame:
    df = add_decade(df)
    result = df.groupby("decade").size().reset_index(name="count")
    return result.sort_values("decade")


def correlation_difficulty_popularity(df: pd.DataFrame) -> Optional[float]:
    if len(df) < 2:
        return None
    corr = df["difficulty"].corr(df["popularity"])
    return None if pd.isna(corr) else round(float(corr), 3)


def high_popularity_low_difficulty(df: pd.DataFrame) -> pd.DataFrame:
    """
    Languages with above-median popularity AND below-or-equal-median
    difficulty, computed dynamically from whatever data is passed in.
    """
    if df.empty:
        return df
    pop_median = df["popularity"].median()
    diff_median = df["difficulty"].median()
    subset = df[(df["popularity"] >= pop_median) & (df["difficulty"] <= diff_median)]
    return subset.sort_values("popularity", ascending=False).reset_index(drop=True)


def generate_insights(df: pd.DataFrame) -> Dict[str, str]:
    """Build a dictionary of plain-language insights computed from df."""
    if df.empty:
        return {}

    most_popular = df.loc[df["popularity"].idxmax()]
    easiest = df.loc[df["difficulty"].idxmin()]
    hardest = df.loc[df["difficulty"].idxmax()]
    most_common_paradigm = df["paradigm"].mode().iloc[0]
    most_common_typing = df["typing"].mode().iloc[0]

    uc_counts = use_case_counts(df)
    most_common_use_case = uc_counts.iloc[0]["use_case"] if not uc_counts.empty else "N/A"

    dc = decade_counts(df)
    most_productive_decade = dc.loc[dc["count"].idxmax(), "decade"] if not dc.empty else "N/A"

    corr = correlation_difficulty_popularity(df)
    if corr is None:
        corr_text = "Not enough data to compute a correlation."
    else:
        strength = "weak" if abs(corr) < 0.3 else "moderate" if abs(corr) < 0.6 else "strong"
        direction = "negative" if corr < 0 else "positive"
        corr_text = f"{strength.capitalize()} {direction} correlation (r = {corr}) between difficulty and popularity."

    return {
        "most_popular": f"{most_popular['language']} ({most_popular['popularity']} popularity points)",
        "easiest": f"{easiest['language']} (difficulty {int(easiest['difficulty'])})",
        "hardest": f"{hardest['language']} (difficulty {int(hardest['difficulty'])})",
        "most_common_paradigm": most_common_paradigm,
        "most_common_typing": most_common_typing,
        "most_common_use_case": most_common_use_case,
        "most_productive_decade": most_productive_decade,
        "difficulty_popularity_relationship": corr_text,
    }
