"""
Plotly chart builders. Every chart shares the same template and color
sequence so the whole app reads as one designed product.
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

COLORS = ["#4361ee", "#3ecf8e", "#f2994a", "#ef5da8", "#7c5cff", "#22c1c3", "#f45b69", "#ffb020"]


def _style(fig: go.Figure, height: int = 360) -> go.Figure:
    fig.update_layout(
        template="plotly_white",
        font=dict(family="Segoe UI, Helvetica, Arial, sans-serif", color="#1f2430", size=12),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=30, b=10),
        height=height,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
    )
    fig.update_xaxes(gridcolor="#e9ecf2", zerolinecolor="#e9ecf2")
    fig.update_yaxes(gridcolor="#e9ecf2", zerolinecolor="#e9ecf2")
    return fig


def fig_popularity_by_language(df: pd.DataFrame) -> go.Figure:
    ordered = df.sort_values("popularity", ascending=False)
    fig = px.bar(ordered, x="language", y="popularity", color="paradigm",
                 color_discrete_sequence=COLORS, labels={"popularity": "Popularity", "language": ""})
    return _style(fig)


def fig_difficulty_by_language(df: pd.DataFrame) -> go.Figure:
    ordered = df.sort_values("difficulty", ascending=False)
    fig = px.bar(ordered, x="language", y="difficulty", color="typing",
                 color_discrete_sequence=COLORS, labels={"difficulty": "Difficulty", "language": ""})
    return _style(fig)


def fig_languages_by_year(df: pd.DataFrame) -> go.Figure:
    fig = px.scatter(df, x="year_created", y=[1] * len(df), text="language", color="paradigm",
                      color_discrete_sequence=COLORS, labels={"year_created": "Year created"})
    fig.update_traces(textposition="top center", marker=dict(size=14))
    fig.update_yaxes(visible=False, showticklabels=False)
    return _style(fig, height=260)


def fig_popularity_vs_difficulty(df: pd.DataFrame) -> go.Figure:
    fig = px.scatter(df, x="difficulty", y="popularity", color="typing", size="popularity",
                      text="language", color_discrete_sequence=COLORS,
                      labels={"difficulty": "Difficulty", "popularity": "Popularity"})
    fig.update_traces(textposition="top center")
    return _style(fig)


def fig_paradigm_distribution(df: pd.DataFrame) -> go.Figure:
    counts = df["paradigm"].value_counts().reset_index()
    counts.columns = ["paradigm", "count"]
    fig = px.pie(counts, names="paradigm", values="count", hole=0.45,
                 color_discrete_sequence=COLORS)
    return _style(fig, height=340)


def fig_typing_distribution(df: pd.DataFrame) -> go.Figure:
    counts = df["typing"].value_counts().reset_index()
    counts.columns = ["typing", "count"]
    fig = px.pie(counts, names="typing", values="count", hole=0.45,
                 color_discrete_sequence=COLORS)
    return _style(fig, height=340)


def fig_use_case_distribution(use_case_counts_df: pd.DataFrame) -> go.Figure:
    ordered = use_case_counts_df.sort_values("count", ascending=True)
    fig = px.bar(ordered, x="count", y="use_case", orientation="h",
                 color_discrete_sequence=[COLORS[0]], labels={"count": "Number of languages", "use_case": ""})
    return _style(fig, height=max(300, 28 * len(ordered)))


def fig_group_bar(df: pd.DataFrame, group_col: str, value_col: str) -> go.Figure:
    fig = px.bar(df, x=group_col, y=value_col, color=group_col,
                 color_discrete_sequence=COLORS, labels={value_col: value_col.capitalize()})
    fig.update_layout(showlegend=False)
    return _style(fig, height=300)
