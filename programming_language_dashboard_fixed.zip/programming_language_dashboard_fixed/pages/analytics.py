"""Analytics page — rankings, decade grouping, and category averages."""

import streamlit as st

from utils.analytics import (
    avg_popularity_by_use_case,
    decade_counts,
    group_stats,
    top_n,
    use_case_counts,
)
from utils.charts import fig_group_bar, fig_use_case_distribution

df = st.session_state.get("filtered_df")

st.markdown(
    '<div class="app-header"><h1>Analytics</h1>'
    '<p>Rankings and category-level comparisons.</p></div>',
    unsafe_allow_html=True,
)

if df is None or df.empty:
    st.markdown(
        '<div class="empty-state">No data available for analytics with the current filters.</div>',
        unsafe_allow_html=True,
    )
    st.stop()

display_cols = ["language", "popularity", "difficulty", "year_created", "paradigm", "typing"]

st.markdown('<div class="section-title">Rankings</div>', unsafe_allow_html=True)
c1, c2 = st.columns(2)
with c1:
    st.caption("Top 5 most popular")
    st.dataframe(top_n(df, "popularity", 5, ascending=False)[display_cols], hide_index=True, use_container_width=True)
with c2:
    st.caption("Bottom 5 by popularity")
    st.dataframe(top_n(df, "popularity", 5, ascending=True)[display_cols], hide_index=True, use_container_width=True)

c3, c4 = st.columns(2)
with c3:
    st.caption("Easiest languages")
    st.dataframe(top_n(df, "difficulty", 5, ascending=True)[display_cols], hide_index=True, use_container_width=True)
with c4:
    st.caption("Most difficult languages")
    st.dataframe(top_n(df, "difficulty", 5, ascending=False)[display_cols], hide_index=True, use_container_width=True)

c5, c6 = st.columns(2)
with c5:
    st.caption("Oldest languages")
    st.dataframe(top_n(df, "year_created", 5, ascending=True)[display_cols], hide_index=True, use_container_width=True)
with c6:
    st.caption("Newest languages")
    st.dataframe(top_n(df, "year_created", 5, ascending=False)[display_cols], hide_index=True, use_container_width=True)

st.markdown('<div class="section-title">Languages by Decade</div>', unsafe_allow_html=True)
dc = decade_counts(df)
st.plotly_chart(fig_group_bar(dc, "decade", "count"), use_container_width=True)

st.markdown('<div class="section-title">By Paradigm</div>', unsafe_allow_html=True)
paradigm_stats = group_stats(df, "paradigm")
c7, c8 = st.columns([1, 1])
with c7:
    st.dataframe(paradigm_stats, hide_index=True, use_container_width=True)
with c8:
    st.plotly_chart(fig_group_bar(paradigm_stats, "paradigm", "popularity"), use_container_width=True)

st.markdown('<div class="section-title">By Typing System</div>', unsafe_allow_html=True)
typing_stats = group_stats(df, "typing")
c9, c10 = st.columns([1, 1])
with c9:
    st.dataframe(typing_stats, hide_index=True, use_container_width=True)
with c10:
    st.plotly_chart(fig_group_bar(typing_stats, "typing", "popularity"), use_container_width=True)

st.markdown('<div class="section-title">Use Cases</div>', unsafe_allow_html=True)
c11, c12 = st.columns(2)
with c11:
    st.caption("Use-case frequency")
    st.plotly_chart(fig_use_case_distribution(use_case_counts(df)), use_container_width=True)
with c12:
    st.caption("Average popularity by use case")
    st.dataframe(avg_popularity_by_use_case(df), hide_index=True, use_container_width=True)
