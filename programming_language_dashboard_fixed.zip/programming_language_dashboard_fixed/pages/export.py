"""Export page — download original, cleaned, filtered, and summary data."""

import pandas as pd
import streamlit as st

from utils.analytics import group_stats

raw_df = st.session_state.get("raw_df")
filtered_df = st.session_state.get("filtered_df")
cleaned_df = st.session_state.get("cleaned_df")

st.markdown(
    '<div class="app-header"><h1>Export</h1>'
    '<p>Download the dataset in the form you need.</p></div>',
    unsafe_allow_html=True,
)

if raw_df is None:
    st.markdown('<div class="empty-state">No data loaded.</div>', unsafe_allow_html=True)
    st.stop()


def build_summary(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    rows = [
        {"Metric": "Total Languages", "Value": len(df)},
        {"Metric": "Average Popularity", "Value": round(df["popularity"].mean(), 2)},
        {"Metric": "Average Difficulty", "Value": round(df["difficulty"].mean(), 2)},
        {"Metric": "Most Popular Language", "Value": df.loc[df["popularity"].idxmax(), "language"]},
        {"Metric": "Oldest Language", "Value": df.loc[df["year_created"].idxmin(), "language"]},
        {"Metric": "Newest Language", "Value": df.loc[df["year_created"].idxmax(), "language"]},
    ]
    summary = pd.DataFrame(rows)
    paradigm_avg = group_stats(df, "paradigm").rename(columns={"paradigm": "Metric", "popularity": "Value"})
    return summary


st.markdown('<div class="section-title">Downloads</div>', unsafe_allow_html=True)

c1, c2 = st.columns(2)
with c1:
    st.download_button(
        "Download Original CSV",
        data=raw_df.to_csv(index=False).encode("utf-8"),
        file_name="programming_languages_original.csv",
        mime="text/csv",
        use_container_width=True,
    )
with c2:
    st.download_button(
        "Download Cleaned CSV",
        data=cleaned_df.to_csv(index=False).encode("utf-8"),
        file_name="programming_languages_cleaned.csv",
        mime="text/csv",
        use_container_width=True,
        disabled=cleaned_df is None,
    )

c3, c4 = st.columns(2)
with c3:
    st.download_button(
        "Download Filtered CSV",
        data=(filtered_df.to_csv(index=False).encode("utf-8") if filtered_df is not None else b""),
        file_name="programming_languages_filtered.csv",
        mime="text/csv",
        use_container_width=True,
        disabled=filtered_df is None or filtered_df.empty,
    )
with c4:
    summary_df = build_summary(filtered_df) if filtered_df is not None and not filtered_df.empty else pd.DataFrame()
    st.download_button(
        "Download Analytics Summary CSV",
        data=summary_df.to_csv(index=False).encode("utf-8"),
        file_name="analytics_summary.csv",
        mime="text/csv",
        use_container_width=True,
        disabled=summary_df.empty,
    )

st.markdown('<div class="section-title">Preview: Analytics Summary</div>', unsafe_allow_html=True)
if filtered_df is not None and not filtered_df.empty:
    st.dataframe(build_summary(filtered_df), hide_index=True, use_container_width=True)
else:
    st.info("No filtered data available to summarize.")
