"""Data Explorer page — searchable, sortable table with download."""

import pandas as pd
import streamlit as st

df = st.session_state.get("filtered_df")

st.markdown(
    '<div class="app-header"><h1>Data Explorer</h1>'
    '<p>Search, sort, and export the filtered dataset.</p></div>',
    unsafe_allow_html=True,
)

if df is None or df.empty:
    st.markdown(
        '<div class="empty-state">No data to explore with the current filters.</div>',
        unsafe_allow_html=True,
    )
    st.stop()

search = st.text_input("Search language", placeholder="e.g. Python", key="explorer_search")

result = df
if search:
    result = df[df["language"].str.contains(search, case=False, na=False)]

st.caption(f"{len(result)} of {len(df)} record(s) shown")

# st.dataframe supports built-in column sorting by clicking headers
st.dataframe(result, use_container_width=True, hide_index=True)

st.download_button(
    "Download filtered data (CSV)",
    data=result.to_csv(index=False).encode("utf-8"),
    file_name="filtered_languages.csv",
    mime="text/csv",
)

st.markdown('<div class="section-title">Column Information</div>', unsafe_allow_html=True)

col_info = []
for col in result.columns:
    col_info.append({
        "Column": col,
        "Data Type": str(result[col].dtype),
        "Non-null Count": int(result[col].notna().sum()),
        "Unique Values": int(result[col].nunique()),
    })

st.dataframe(pd.DataFrame(col_info), use_container_width=True, hide_index=True)
