"""Insights page — plain-language insights, all computed from the data."""

import streamlit as st

from utils.analytics import generate_insights, high_popularity_low_difficulty

df = st.session_state.get("filtered_df")

st.markdown(
    '<div class="app-header"><h1>Insights</h1>'
    '<p>Automatically generated observations based on the current data selection.</p></div>',
    unsafe_allow_html=True,
)

if df is None or df.empty:
    st.markdown(
        '<div class="empty-state">No data available to generate insights with the current filters.</div>',
        unsafe_allow_html=True,
    )
    st.stop()

insights = generate_insights(df)

labels = {
    "most_popular": "Most popular language",
    "easiest": "Easiest language",
    "hardest": "Most difficult language",
    "most_common_paradigm": "Most common paradigm",
    "most_common_typing": "Most common typing system",
    "most_common_use_case": "Most common use case",
    "most_productive_decade": "Most productive decade",
    "difficulty_popularity_relationship": "Difficulty vs. popularity relationship",
}

cols = st.columns(2)
for i, (key, label) in enumerate(labels.items()):
    with cols[i % 2]:
        st.markdown(
            f"""<div class="insight-card">
                    <div class="insight-title">{label}</div>
                    <div class="insight-value">{insights.get(key, 'N/A')}</div>
                </div>""",
            unsafe_allow_html=True,
        )

st.markdown('<div class="section-title">High Popularity, Low Difficulty</div>', unsafe_allow_html=True)
st.caption("Languages with above-median popularity and below-or-equal-median difficulty in the current selection.")
combo = high_popularity_low_difficulty(df)
if combo.empty:
    st.info("No languages meet this combined criterion in the current selection.")
else:
    st.dataframe(
        combo[["language", "popularity", "difficulty", "paradigm", "typing"]],
        hide_index=True,
        use_container_width=True,
    )
