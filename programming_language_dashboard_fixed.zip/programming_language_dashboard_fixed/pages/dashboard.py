"""Dashboard page — overview KPIs and charts, driven by global filters."""

import streamlit as st

from utils.charts import (
    fig_difficulty_by_language,
    fig_languages_by_year,
    fig_paradigm_distribution,
    fig_popularity_by_language,
    fig_popularity_vs_difficulty,
    fig_typing_distribution,
    fig_use_case_distribution,
)
from utils.analytics import use_case_counts

df = st.session_state.get("filtered_df")

st.markdown(
    """
    <div class="app-header">
        <h1>Programming Languages Analytics</h1>
        <p>Explore programming languages through popularity, difficulty,
        history, paradigms, typing systems and use cases.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

if df is None or df.empty:
    st.markdown(
        '<div class="empty-state">No languages match the current filters. '
        'Try widening your selection in the sidebar.</div>',
        unsafe_allow_html=True,
    )
    st.stop()

# ---------------------------------------------------------------------
# KPI cards
# ---------------------------------------------------------------------
oldest = df.loc[df["year_created"].idxmin()]
newest = df.loc[df["year_created"].idxmax()]
most_popular = df.loc[df["popularity"].idxmax()]

kpis = [
    ("Total Languages", str(len(df))),
    ("Average Popularity", f"{df['popularity'].mean():.1f}"),
    ("Average Difficulty", f"{df['difficulty'].mean():.1f}"),
    ("Oldest Language", f"{oldest['language']} ({int(oldest['year_created'])})"),
    ("Newest Language", f"{newest['language']} ({int(newest['year_created'])})"),
    ("Most Popular Language", most_popular["language"]),
]

cols = st.columns(3)
for i, (label, value) in enumerate(kpis):
    with cols[i % 3]:
        st.markdown(
            f"""<div class="kpi-card">
                    <div class="kpi-label">{label}</div>
                    <div class="kpi-value">{value}</div>
                </div>""",
            unsafe_allow_html=True,
        )
    if i % 3 == 2 and i != len(kpis) - 1:
        cols = st.columns(3)

# ---------------------------------------------------------------------
# Charts
# ---------------------------------------------------------------------
st.markdown('<div class="section-title">Popularity & Difficulty</div>', unsafe_allow_html=True)
c1, c2 = st.columns(2)
with c1:
    st.plotly_chart(fig_popularity_by_language(df), use_container_width=True)
with c2:
    st.plotly_chart(fig_difficulty_by_language(df), use_container_width=True)

c3, c4 = st.columns(2)
with c3:
    st.plotly_chart(fig_popularity_vs_difficulty(df), use_container_width=True)
with c4:
    st.plotly_chart(fig_languages_by_year(df), use_container_width=True)

st.markdown('<div class="section-title">Paradigm & Typing</div>', unsafe_allow_html=True)
c5, c6 = st.columns(2)
with c5:
    st.plotly_chart(fig_paradigm_distribution(df), use_container_width=True)
with c6:
    st.plotly_chart(fig_typing_distribution(df), use_container_width=True)

st.markdown('<div class="section-title">Use Case Distribution</div>', unsafe_allow_html=True)
st.plotly_chart(fig_use_case_distribution(use_case_counts(df)), use_container_width=True)
