"""Data Quality page — inspects the RAW dataset (not the filtered one)."""

import pandas as pd
import streamlit as st

from utils.cleaning import data_quality_report, validate_values

raw_df = st.session_state.get("raw_df")
cleaned_df = st.session_state.get("cleaned_df")

st.markdown(
    '<div class="app-header"><h1>Data Quality</h1>'
    '<p>Quality report for the full, unfiltered dataset. The original CSV is never modified.</p></div>',
    unsafe_allow_html=True,
)

if raw_df is None or raw_df.empty:
    st.markdown('<div class="empty-state">No data loaded.</div>', unsafe_allow_html=True)
    st.stop()

report = data_quality_report(raw_df)

st.markdown('<div class="section-title">Overview</div>', unsafe_allow_html=True)
c1, c2, c3 = st.columns(3)
c1.markdown(f'<div class="kpi-card"><div class="kpi-label">Total Rows</div><div class="kpi-value">{report["total_rows"]}</div></div>', unsafe_allow_html=True)
c2.markdown(f'<div class="kpi-card"><div class="kpi-label">Total Columns</div><div class="kpi-value">{report["total_columns"]}</div></div>', unsafe_allow_html=True)
c3.markdown(f'<div class="kpi-card"><div class="kpi-label">Duplicate Rows</div><div class="kpi-value">{report["duplicate_rows"]}</div></div>', unsafe_allow_html=True)

st.markdown('<div class="section-title">Missing Values</div>', unsafe_allow_html=True)
missing_df = pd.DataFrame(
    [{"Column": k, "Missing Values": v} for k, v in report["missing_values"].items()]
)
st.dataframe(missing_df, hide_index=True, use_container_width=True)

st.markdown('<div class="section-title">Data Types & Unique Values</div>', unsafe_allow_html=True)
dtype_df = pd.DataFrame([
    {
        "Column": col,
        "Data Type": report["dtypes"][col],
        "Unique Values": report["unique_values"][col],
    }
    for col in raw_df.columns
])
st.dataframe(dtype_df, hide_index=True, use_container_width=True)

st.markdown('<div class="section-title">Numeric Summary</div>', unsafe_allow_html=True)
st.dataframe(report["numeric_summary"], use_container_width=True)

st.markdown('<div class="section-title">Validation Issues</div>', unsafe_allow_html=True)
issues = validate_values(raw_df)
if issues:
    for issue in issues:
        st.warning(issue)
else:
    st.success("No validation issues found.")

st.markdown('<div class="section-title">Cleaned Data Preview</div>', unsafe_allow_html=True)
st.caption(f"{len(cleaned_df)} of {len(raw_df)} rows kept after cleaning (in-memory only — original file untouched).")
st.dataframe(cleaned_df, hide_index=True, use_container_width=True)

st.download_button(
    "Download cleaned data (CSV)",
    data=cleaned_df.to_csv(index=False).encode("utf-8"),
    file_name="cleaned_languages.csv",
    mime="text/csv",
)
